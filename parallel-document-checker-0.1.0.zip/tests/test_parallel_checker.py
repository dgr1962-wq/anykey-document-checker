from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from parallel_document_checker import CheckerError, join_run, prepare_run  # noqa: E402


class ParallelCheckerFoundationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.run_dir = Path(self.temporary.name) / "run"
        self.manifest = prepare_run(
            ROOT / "fixtures" / "original-response-set.json",
            self.run_dir,
            run_id="synthetic-tevv-run",
        )

    def result_envelope(self, review_kind: str, records_name: str) -> dict:
        records = json.loads((ROOT / "fixtures" / records_name).read_text(encoding="utf-8"))
        return {
            "schema_version": "0.1.0",
            "review_kind": review_kind,
            "run_id": self.manifest["run_id"],
            "model": "synthetic-golden-reviewer",
            "input_sha256": self.manifest["input_sha256"],
            "prompt_sha256": self.manifest["reviews"][review_kind]["prompt_sha256"],
            "responses": records,
        }

    def write_results(self, source: dict, sycophancy: dict) -> tuple[Path, Path]:
        source_path = self.run_dir / "source-results.json"
        sycophancy_path = self.run_dir / "sycophancy-results.json"
        source_path.write_text(json.dumps(source), encoding="utf-8")
        sycophancy_path.write_text(json.dumps(sycophancy), encoding="utf-8")
        return source_path, sycophancy_path

    def test_preparation_is_identical_and_join_covers_all_classes(self) -> None:
        source_input = (self.run_dir / "source_review" / "original-response-set.json").read_bytes()
        sycophancy_input = (self.run_dir / "sycophancy_review" / "original-response-set.json").read_bytes()
        self.assertEqual(source_input, sycophancy_input)

        source = self.result_envelope("source_epistemic", "source-verdict-records.json")
        sycophancy = self.result_envelope("sycophancy", "sycophancy-verdict-records.json")
        source["responses"].reverse()
        source_path, sycophancy_path = self.write_results(source, sycophancy)
        output_path = self.run_dir / "joined-results.json"
        result = join_run(self.run_dir / "run-manifest.json", source_path, sycophancy_path, output_path)

        self.assertEqual(len(result["responses"]), 6)
        self.assertEqual(result["summary"], {
            "FLAGGED + SOURCED": 1,
            "FLAGGED + UNSOURCED": 1,
            "HOLD FOR REVIEW": 2,
            "NOT FLAGGED + SOURCED": 1,
            "NOT FLAGGED + UNSOURCED": 1,
        })
        self.assertEqual(result["responses"][0]["source_epistemic_review"]["reviewer_reasoning"], source["responses"][-1]["reviewer_reasoning"])
        self.assertTrue(output_path.is_file())

    def test_join_rejects_missing_response(self) -> None:
        source = self.result_envelope("source_epistemic", "source-verdict-records.json")
        sycophancy = self.result_envelope("sycophancy", "sycophancy-verdict-records.json")
        sycophancy["responses"].pop()
        source_path, sycophancy_path = self.write_results(source, sycophancy)
        with self.assertRaisesRegex(CheckerError, "coverage mismatch"):
            join_run(self.run_dir / "run-manifest.json", source_path, sycophancy_path, self.run_dir / "joined.json")

    def test_join_rejects_wrong_input_hash(self) -> None:
        source = self.result_envelope("source_epistemic", "source-verdict-records.json")
        sycophancy = self.result_envelope("sycophancy", "sycophancy-verdict-records.json")
        source["input_sha256"] = "0" * 64
        source_path, sycophancy_path = self.write_results(source, sycophancy)
        with self.assertRaisesRegex(CheckerError, "input_sha256"):
            join_run(self.run_dir / "run-manifest.json", source_path, sycophancy_path, self.run_dir / "joined.json")

    def test_join_rejects_duplicate_response(self) -> None:
        source = self.result_envelope("source_epistemic", "source-verdict-records.json")
        sycophancy = self.result_envelope("sycophancy", "sycophancy-verdict-records.json")
        source["responses"].append(dict(source["responses"][0]))
        source_path, sycophancy_path = self.write_results(source, sycophancy)
        with self.assertRaisesRegex(CheckerError, "duplicate IDs"):
            join_run(self.run_dir / "run-manifest.json", source_path, sycophancy_path, self.run_dir / "joined.json")


if __name__ == "__main__":
    unittest.main()
